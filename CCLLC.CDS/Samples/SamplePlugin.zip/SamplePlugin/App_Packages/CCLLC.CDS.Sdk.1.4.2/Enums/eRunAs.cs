﻿namespace CCLLC.CDS.Sdk
{
    public enum eRunAs
    {
        User = 1,
        System
    }
}
