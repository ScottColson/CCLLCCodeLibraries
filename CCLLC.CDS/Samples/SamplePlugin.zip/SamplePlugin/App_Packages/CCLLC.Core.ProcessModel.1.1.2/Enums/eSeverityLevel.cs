﻿namespace CCLLC.Core
{
    public enum eSeverityLevel
    {
        Verbose,
        Information,
        Warning,
        Error,
        Critical
    }
}
