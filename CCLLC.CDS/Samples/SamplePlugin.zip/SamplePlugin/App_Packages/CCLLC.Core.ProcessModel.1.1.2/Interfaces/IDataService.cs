﻿namespace CCLLC.Core
{
    public interface IDataService
    {
    }
}
