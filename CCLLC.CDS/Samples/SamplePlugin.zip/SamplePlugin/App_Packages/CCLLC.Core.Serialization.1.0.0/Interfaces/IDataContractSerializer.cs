﻿namespace CCLLC.Core.Serialization
{
    public interface IDataContractSerializer : IDataSerializer
    {      
    }
}
