﻿namespace CCLLC.Core.Serialization
{
    public interface IJSONContractSerializer : IDataContractSerializer
    {
    }
}
