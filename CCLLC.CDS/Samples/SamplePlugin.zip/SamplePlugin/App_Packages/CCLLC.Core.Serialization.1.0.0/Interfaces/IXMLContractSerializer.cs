﻿namespace CCLLC.Core.Serialization
{
    public interface IXMLContractSerializer : IDataContractSerializer
    {
    }
}
