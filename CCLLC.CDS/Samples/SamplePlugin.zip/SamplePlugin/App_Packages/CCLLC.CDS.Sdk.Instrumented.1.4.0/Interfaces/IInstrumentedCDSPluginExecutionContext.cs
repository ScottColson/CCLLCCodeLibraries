﻿namespace CCLLC.CDS.Sdk
{
    public interface IInstrumentedCDSPluginExecutionContext : IInstrumentedCDSExecutionContext, ICDSPluginExecutionContext
    {
    }
}
