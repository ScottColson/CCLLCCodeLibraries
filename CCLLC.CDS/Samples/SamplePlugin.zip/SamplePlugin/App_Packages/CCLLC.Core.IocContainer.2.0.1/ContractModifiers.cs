﻿using System;

namespace CCLLC.Core
{
    class ContractModifiers
    {
        public Type Type { get; set; }
        public bool SingleInstance { get; set; }
    }
}
