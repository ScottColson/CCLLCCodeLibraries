﻿namespace CCLLC.Telemetry
{
    public interface IPageViewDataModel : IDataModel
    {
    }
}
