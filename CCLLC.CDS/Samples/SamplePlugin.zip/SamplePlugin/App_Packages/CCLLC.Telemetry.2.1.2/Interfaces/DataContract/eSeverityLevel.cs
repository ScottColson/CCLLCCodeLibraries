﻿namespace CCLLC.Telemetry
{
    public enum eSeverityLevel
    {
        Verbose,
        Information,
        Warning,
        Error,
        Critical
    }
}
