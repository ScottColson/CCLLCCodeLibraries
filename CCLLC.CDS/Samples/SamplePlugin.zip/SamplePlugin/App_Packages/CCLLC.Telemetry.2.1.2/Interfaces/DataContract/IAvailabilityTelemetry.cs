﻿namespace CCLLC.Telemetry
{
    public interface IAvailabilityTelemetry : ITelemetry, IDataModelTelemetry<IAvailabilityDataModel>
    {
    }
}
