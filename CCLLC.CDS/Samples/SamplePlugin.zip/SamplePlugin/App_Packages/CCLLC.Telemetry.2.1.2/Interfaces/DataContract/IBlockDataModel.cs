﻿namespace CCLLC.Telemetry
{
    public interface IBlockDataModel : IDataModel
    {
    }
}
