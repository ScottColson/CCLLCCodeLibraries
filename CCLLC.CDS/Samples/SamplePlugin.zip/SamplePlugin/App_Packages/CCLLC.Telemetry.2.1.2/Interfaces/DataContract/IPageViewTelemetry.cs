﻿namespace CCLLC.Telemetry
{
    public interface IPageViewTelemetry : ITelemetry, IDataModelTelemetry<IPageViewDataModel>
    {
    }
}
