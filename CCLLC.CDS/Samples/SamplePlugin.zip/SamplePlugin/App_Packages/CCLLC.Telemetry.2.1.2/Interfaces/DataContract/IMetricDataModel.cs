﻿namespace CCLLC.Telemetry
{
    public interface IMetricDataModel : IDataModel
    {
    }
}
