﻿namespace CCLLC.Telemetry
{
    public interface IAvailabilityDataModel : IDataModel
    {
    }
}
