﻿namespace CCLLC.Telemetry
{
    public interface ISupportSampling
    {
        double? SamplingPercentage { get; set; }
    }
}
