﻿namespace CCLLC.Telemetry
{
    public interface ISupportDataKeyContext
    {
        IDataKeyContext Data { get; }
    }
}
